# Web Applications with FastAPI course

Demo code and other handouts for students of our FastAPI Web Apps course.

[![](./data/readme_resources/fastapi-apps.png)](https://training.talkpython.fm/getnotified)

Course coming early 2021. [Get notified](https://training.talkpython.fm/getnotified).

See the [course revisions and change log](./revisions.md).