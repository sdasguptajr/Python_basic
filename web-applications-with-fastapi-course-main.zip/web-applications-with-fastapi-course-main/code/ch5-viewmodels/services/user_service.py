def user_count() -> int:
    return 73_874
