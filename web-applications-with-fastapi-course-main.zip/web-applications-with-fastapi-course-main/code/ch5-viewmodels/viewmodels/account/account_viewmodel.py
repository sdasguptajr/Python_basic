from viewmodels.shared.viewmodel import ViewModelBase


class AccountViewModel(ViewModelBase):
    pass
