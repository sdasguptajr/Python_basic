from viewmodels.shared.viewmodel import ViewModelBase


class LoginViewModel(ViewModelBase):
    pass
