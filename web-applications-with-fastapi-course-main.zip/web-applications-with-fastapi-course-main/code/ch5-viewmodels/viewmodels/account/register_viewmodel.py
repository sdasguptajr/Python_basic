from viewmodels.shared.viewmodel import ViewModelBase


class RegisterViewModel(ViewModelBase):
    pass
