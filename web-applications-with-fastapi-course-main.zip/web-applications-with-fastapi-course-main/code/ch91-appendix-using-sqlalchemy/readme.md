# See Building Data-Driven Web Apps with Flask and SQLAlchemy Chapter

This chapter did not have its own source code. The appendix's source code is over here in the Data-driven Flask materials.

[https://github.com/talkpython/data-driven-web-apps-with-flask/tree/master/app/ch10_using_sqlachemy](https://github.com/talkpython/data-driven-web-apps-with-flask/tree/master/app/ch10_using_sqlachemy)

