# See Modern API's with FastAPI Chapter

This chapter did not have its own source code. It was simply showing the deployment section from our other FastAPI course. See the code here to follow along (although adapting what is here should be trivial).

[https://github.com/talkpython/modern-apis-with-fastapi/tree/main/ch08-deployment](https://github.com/talkpython/modern-apis-with-fastapi/tree/main/ch08-deployment)
