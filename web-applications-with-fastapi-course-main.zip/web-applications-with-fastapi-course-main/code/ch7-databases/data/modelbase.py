import sqlalchemy.ext.declarative

SqlAlchemyBase = sqlalchemy.ext.declarative.declarative_base()
