import fastapi

router = fastapi.APIRouter()
